import { kv } from '@vercel/kv';
import bcrypt from 'bcryptjs';

export default async function handler(request, response) {
    if (request.method !== 'POST') {
        return response.status(405).json({ message: 'Method Not Allowed' });
    }

    try {
        const { username, email, password } = request.body;

        if (!username || !email || !password) {
            return response.status(400).json({ message: 'Username, email, dan password diperlukan.' });
        }

        // Cek apakah username sudah ada
        const existingUser = await kv.get(`user:${username}`);
        if (existingUser) {
            return response.status(409).json({ message: 'Username sudah digunakan.' });
        }

        // Hash password sebelum disimpan
        const hashedPassword = await bcrypt.hash(password, 10); // 10 adalah salt rounds

        // Simpan user baru ke Vercel KV
        const newUser = {
            username,
            email,
            password: hashedPassword,
        };
        await kv.set(`user:${username}`, JSON.stringify(newUser));

        return response.status(201).json({ message: 'Registrasi berhasil!' });

    } catch (error) {
        console.error(error);
        return response.status(500).json({ message: 'Terjadi kesalahan pada server.' });
    }
}