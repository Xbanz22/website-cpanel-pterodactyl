// File: plugins/deposit.js
const axios = require("axios");
const QRCode = require("qrcode");
const fs = require("fs");

// Pilihan footer random (elegan & jualan)
const successFooters = [
  "🔰 *Banzz BotShop v2* — Layanan topup cepat, aman, dan terpercaya.",
  "⚡ *Banzz BotShop v2* — Fast payment, instant balance.",
  "🛒 *Banzz BotShop v2* — Belanja digital jadi lebih mudah & otomatis.",
  "💎 *Banzz BotShop v2* — Premium digital store dengan pelayanan terbaik.",
  "📲 *Banzz BotShop v2* — Topup instan, transaksi langsung masuk.",
  "🛡️ *Banzz BotShop v2* — Keamanan transaksi prioritas utama.",
  "✨ *Banzz BotShop v2* — Solusi cepat untuk semua kebutuhan digital.",
  "🎯 *Banzz BotShop v2* — Fokus pada kepuasan & kecepatan layanan.",
  "💳 *Banzz BotShop v2* — Mudah, cepat, dan otomatis 24/7.",
  "🌐 *Banzz BotShop v2* — Marketplace digital terpercaya pilihan Anda.",
  "🏆 *Banzz BotShop v2* — Ribuan transaksi sukses setiap harinya.",
  "🚀 *Banzz BotShop v2* — Deposit lebih cepat, order lebih lancar."
];
const getRandomFooter = () =>
  successFooters[Math.floor(Math.random() * successFooters.length)];

const handler = async (m, { bani, text, sender, isCreator }) => {
  // 1. Validasi Input
  if (!text || isNaN(text)) {
    return m.reply(
      "❌ Masukkan nominal deposit yang valid!\n\nContoh: *.deposit 10000*"
    );
  }

  const nominalUser = parseInt(text.replace(/[^0-9]/g, ""));
  if (nominalUser <= 999) {
    return m.reply("❌ Nominal minimal untuk deposit adalah Rp 1.000.");
  }

  // 2. Konfigurasi API
  const apiKey = "sk-dqf8wbmkc5kv9o"; // ganti dengan API key
  const depositUrl = "https://requimeboost.id/api/h2h/deposit/create";
  const statusUrl = "https://requimeboost.id/api/h2h/deposit/status";

  if (apiKey.includes("GANTI_DENGAN") || !depositUrl) {
    return m.reply(
      isCreator
        ? "❌ API Key/URL belum diatur di dalam plugin."
        : "❌ Fitur deposit sedang dalam perbaikan."
    );
  }

  try {
    const initialReply = await m.reply(
      "⏳ Sedang membuat permintaan deposit, mohon tunggu sebentar..."
    );

    const fee = Math.floor(Math.random() * (500 - 200 + 1)) + 200;
    const nominalBayar = nominalUser + fee;

    // 3. Request ke API
    const params = new URLSearchParams();
    params.append("api_key", apiKey);
    params.append("reff_id", `dep-${sender.split("@")[0]}-${Date.now()}`);
    params.append("nominal", nominalBayar.toString());
    params.append("type", "ewallet");
    params.append("method", "QRISFAST");

    const response = await axios.post(depositUrl, params, {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });

    const data = response.data;
    if (!data.status) {
      return m.reply(`❌ Deposit gagal: ${data.message || "Error tidak diketahui."}`);
    }

    const d = data.data;

    // 4. Simpan histori
    const historyFilePath = "./Data/depositHistory.json";
    const depositHistory = fs.existsSync(historyFilePath)
      ? JSON.parse(fs.readFileSync(historyFilePath))
      : {};
    depositHistory[d.id] = {
      sender: sender,
      reff_id: d.reff_id,
      status: "pending",
    };
    fs.writeFileSync(historyFilePath, JSON.stringify(depositHistory, null, 2));

    let qrBuffer;
    if (d.qr_image_string) {
      qrBuffer = await QRCode.toBuffer(d.qr_image_string, { width: 400 });
    }

    // --- TEMPLATE INVOICE ---
    const invoiceText = `
━━━━━━━━━━━━━━━━━━
✅ *INVOICE DEPOSIT*
━━━━━━━━━━━━━━━━━━

📌 *Informasi Transaksi*
🆔 ID Transaksi  : ${d.id}
👤 Akun Pengguna : @${sender.split("@")[0]}
📅 Tanggal       : ${new Date().toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
    })}

💰 Nominal       : Rp ${nominalUser.toLocaleString("id-ID")}
💸 Biaya Admin   : Rp ${fee.toLocaleString("id-ID")}
📥 Saldo Diterima: Rp ${d.get_balance.toLocaleString("id-ID")}

🏦 Metode        : QRIS (E-Wallet)
⏳ Status        : ${d.status.toUpperCase()}
⏰ Kedaluwarsa   : ${d.expired_at}

━━━━━━━━━━━━━━━━━━
📌 *Instruksi Pembayaran*
1️⃣ Buka aplikasi e-wallet (OVO, DANA, GoPay, ShopeePay, LinkAja, dll).
2️⃣ Pilih menu *Scan QR* lalu arahkan ke QR Code di atas.
3️⃣ Pastikan nominal yang tampil sesuai.
4️⃣ Konfirmasi & lakukan pembayaran.
5️⃣ Saldo otomatis masuk setelah transaksi berhasil.

━━━━━━━━━━━━━━━━━━
⚠️ *Catatan Penting*
- Jangan bagikan QR Code kepada orang lain.
- Invoice hanya berlaku 1 kali pembayaran.
- Jika nominal berbeda, pembayaran otomatis ditolak.
- Sistem akan membatalkan transaksi jika melebihi waktu kedaluwarsa (5 menit).
━━━━━━━━━━━━━━━━━━
`.trim();

    const messageOptions = {
      caption: invoiceText,
      footer: "🔰 Sistem Deposit Otomatis",
      buttons: [
        {
          buttonId: `.cekstatus ${d.id}`,
          buttonText: { displayText: "🔄 Cek Status Manual" },
          type: 1,
        },
        {
          buttonId: `.canceldeposit ${d.id}`,
          buttonText: { displayText: "❌ Batalkan Manual" },
          type: 1,
        },
      ],
      headerType: 4,
    };

    if (d.qr_image_url) {
      messageOptions.image = { url: d.qr_image_url };
    } else {
      messageOptions.image = qrBuffer;
    }

    const sentInvoice = await bani.sendMessage(
      m.key.remoteJid,
      messageOptions,
      { quoted: m }
    );

    await bani.sendMessage(m.key.remoteJid, { delete: initialReply.key });

    // --- TEXT SUKSES BARU ---
    const successText = (successAmount, saldoBefore, saldoAfter) => `
🟢 𝗗𝗘𝗣𝗢𝗦𝗜𝗧 𝗦𝗨𝗞𝗦𝗘𝗦 — *Banzz BotShop v2*
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┌─ 𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶
│ 👤 Pengguna   : @${sender.split("@")[0]}
│ 🏷 Provider   : Banzz BotShop
│ 🔖 Referensi  : ${d.id}
│ 🕒 Waktu      : ${new Date().toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta",
      })}
├─ 𝗗𝗲𝘁𝗮𝗶𝗹 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻
│ 💵 Nominal    : Rp ${nominalUser.toLocaleString("id-ID")}
│ 🧾 Biaya      : Rp ${fee.toLocaleString("id-ID")}
│ 💳 Total      : Rp ${(nominalUser + fee).toLocaleString("id-ID")}
│ 💰 Saldo Masuk: Rp ${successAmount.toLocaleString("id-ID")}
├─ 𝗦𝗮𝗹𝗱𝗼
│ 🔁 Sebelum    : Rp ${saldoBefore.toLocaleString("id-ID")}
│ ✅ Sesudah    : Rp ${saldoAfter.toLocaleString("id-ID")}
└━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${getRandomFooter()}
`.trim();

    // --- POLLING STATUS ---
    const checkInterval = 15000;
    const expiryTime = 5 * 60 * 1000;
    const startTime = Date.now();

    const checkStatusInterval = setInterval(async () => {
      if (Date.now() - startTime > expiryTime) {
        clearInterval(checkStatusInterval);
        const currentHistory = JSON.parse(fs.readFileSync(historyFilePath));
        if (currentHistory[d.id] && currentHistory[d.id].status === "pending") {
          await bani.sendMessage(m.key.remoteJid, { delete: sentInvoice.key });
          await m.reply("⌛ Invoice kadaluarsa, silakan buat deposit ulang.");
          currentHistory[d.id].status = "expired";
          fs.writeFileSync(
            historyFilePath,
            JSON.stringify(currentHistory, null, 2)
          );
        }
        return;
      }

      try {
        const statusResponse = await axios.post(
          statusUrl,
          { id: d.id, api_key: apiKey },
          { headers: { "Content-Type": "application/json" } }
        );
        const currentStatus = statusResponse.data?.data?.status;

        if (currentStatus === "success") {
          clearInterval(checkStatusInterval);

          const successAmount = statusResponse.data.data.get_balance;
          const saldoBefore = 1000; // TODO: ambil dari database saldo asli user
          const saldoAfter = saldoBefore + successAmount;

          await m.reply(successText(successAmount, saldoBefore, saldoAfter));

          const currentHistory = JSON.parse(fs.readFileSync(historyFilePath));
          if (currentHistory[d.id]) {
            currentHistory[d.id].status = "success";
            fs.writeFileSync(
              historyFilePath,
              JSON.stringify(currentHistory, null, 2)
            );
          }

          await bani.sendMessage(m.key.remoteJid, { delete: sentInvoice.key });
        } else if (currentStatus === "failed") {
          clearInterval(checkStatusInterval);
          await m.reply("❌ Pembayaran gagal, silakan ulangi deposit.");
          const currentHistory = JSON.parse(fs.readFileSync(historyFilePath));
          if (currentHistory[d.id]) {
            currentHistory[d.id].status = "failed";
            fs.writeFileSync(
              historyFilePath,
              JSON.stringify(currentHistory, null, 2)
            );
          }
          await bani.sendMessage(m.key.remoteJid, { delete: sentInvoice.key });
        }
      } catch (pollError) {
        console.error("Error saat polling status:", pollError.message);
      }
    }, checkInterval);
  } catch (err) {
    console.error(
      "Error saat membuat deposit:",
      err.response ? err.response.data : err.message
    );
    m.reply("❌ Terjadi kesalahan saat menghubungi server pembayaran.");
  }
};

handler.command = ["deposit"];
handler.tags = ["payment"];
handler.help = ["deposit <nominal>"];

module.exports = handler;


///////////////////////

// File: plugins/deposit.js
const axios = require("axios");
const QRCode = require("qrcode");
const fs = require("fs");

const handler = async (m, { bani, text, sender, isCreator }) => {
  // 1. Validasi Input Pengguna
  if (!text || isNaN(text)) {
    return m.reply(
      "❌ Masukkan nominal deposit yang valid!\n\nContoh: *.deposit 10000*"
    );
  }

  const nominalUser = parseInt(text.replace(/[^0-9]/g, ""));
  if (nominalUser <= 999) {
    return m.reply("❌ Nominal minimal untuk deposit adalah Rp 1.000.");
  }

  // 2. Konfigurasi API
  const apiKey = "sk-dqf8wbmkc5kv9o"; // Ganti dengan API Key Anda yang valid
  const depositUrl = "https://requimeboost.id/api/h2h/deposit/create";
  const statusUrl = "https://requimeboost.id/api/h2h/deposit/status";

  if (apiKey.includes("GANTI_DENGAN") || !depositUrl) {
    console.error("API Key/URL belum diatur di dalam plugin deposit.js");
    return m.reply(
      isCreator
        ? "❌ API Key/URL belum diatur di dalam plugin."
        : "❌ Fitur deposit sedang dalam perbaikan."
    );
  }

  try {
    const initialReply = await m.reply(
      "⏳ Sedang membuat permintaan deposit, mohon tunggu sebentar..."
    );

    const fee = Math.floor(Math.random() * (500 - 200 + 1)) + 200;
    const nominalBayar = nominalUser + fee;

    // 3. Menyiapkan dan Mengirim Permintaan ke API
    const params = new URLSearchParams();
    params.append("api_key", apiKey);
    params.append(
      "reff_id",
      `dep-${sender.split("@")[0]}-${Date.now()}`
    );
    params.append("nominal", nominalBayar.toString());
    params.append("type", "ewallet");
    params.append("method", "QRISFAST");

    const response = await axios.post(depositUrl, params, {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    });

    const data = response.data;
    if (!data.status) {
      return m.reply(
        `❌ Deposit gagal: ${data.message || "Error tidak diketahui dari API."}`
      );
    }

    const d = data.data;

    // 4. Simpan histori transaksi awal
    const historyFilePath = "./Data/depositHistory.json";
    const depositHistory = JSON.parse(fs.readFileSync(historyFilePath));
    depositHistory[d.id] = {
      sender: sender,
      reff_id: d.reff_id,
      status: "pending",
    };
    fs.writeFileSync(historyFilePath, JSON.stringify(depositHistory, null, 2));

    let qrBuffer;
    if (d.qr_image_url) {
      // Biarkan Baileys yang menangani URL
    } else if (d.qr_image_string) {
      qrBuffer = await QRCode.toBuffer(d.qr_image_string, { width: 400 });
    } else {
      throw new Error("API tidak memberikan QR Code yang valid.");
    }

    // --- TEMPLATE PESAN ---
    const invoiceText = `
━━━━━━━━━━━━━━━━━━
✅ *INVOICE DEPOSIT*
━━━━━━━━━━━━━━━━━━

📌 *Informasi Transaksi*  
🆔 ID Transaksi  : ${d.id}  
👤 Akun Pengguna : @${sender.split("@")[0]}  
📅 Tanggal       : ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}

💰 Nominal       : Rp ${nominalUser.toLocaleString("id-ID")}  
💸 Biaya Admin   : Rp ${fee.toLocaleString("id-ID")}  
📥 Saldo Diterima: Rp ${d.get_balance.toLocaleString("id-ID")}  

🏦 Metode        : QRIS (E-Wallet)  
⏳ Status        : ${d.status.toUpperCase()}  
⏰ Kedaluwarsa   : ${d.expired_at}

━━━━━━━━━━━━━━━━━━
📌 *Instruksi Pembayaran*  
1️⃣ Buka aplikasi e-wallet (OVO, DANA, GoPay, ShopeePay, LinkAja, dll).  
2️⃣ Pilih menu *Scan QR* lalu arahkan ke QR Code di atas.  
3️⃣ Pastikan nominal yang tampil sesuai.  
4️⃣ Konfirmasi & lakukan pembayaran.  
5️⃣ Saldo otomatis masuk setelah transaksi berhasil.  

━━━━━━━━━━━━━━━━━━
⚠️ *Catatan Penting*  
- Jangan bagikan QR Code kepada orang lain.  
- Invoice hanya berlaku 1 kali pembayaran.  
- Jika nominal berbeda, pembayaran otomatis ditolak.  
- Sistem akan membatalkan transaksi jika melebihi waktu kedaluwarsa (5 menit).  

━━━━━━━━━━━━━━━━━━
`.trim();

    const successText = (successAmount) => `
━━━━━━━━━━━━━━━━━━
🎉 *PEMBAYARAN BERHASIL*
━━━━━━━━━━━━━━━━━━

📌 *Detail Transaksi*  
🆔 ID Transaksi  : ${d.id}  
👤 Akun Pengguna : @${sender.split("@")[0]}  
📅 Tanggal Bayar : ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}

💰 Nominal       : Rp ${nominalUser.toLocaleString("id-ID")}  
💸 Biaya Admin   : Rp ${fee.toLocaleString("id-ID")}  
📥 Saldo Masuk   : Rp ${successAmount.toLocaleString("id-ID")}  

━━━━━━━━━━━━━━━━━━
✅ Saldo Anda telah ditambahkan secara otomatis.  
Terima kasih telah menggunakan layanan deposit 🙏  

💡 Tips: Simpan ID Transaksi sebagai bukti pembayaran.
━━━━━━━━━━━━━━━━━━
🔰 Sistem Deposit Otomatis
`.trim();

    const failedText = `
━━━━━━━━━━━━━━━━━━
❌ *PEMBAYARAN GAGAL*
━━━━━━━━━━━━━━━━━━

📌 *Detail Transaksi*  
🆔 ID Transaksi  : ${d.id}  
👤 Akun Pengguna : @${sender.split("@")[0]}  
📅 Tanggal       : ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}

💰 Nominal       : Rp ${nominalUser.toLocaleString("id-ID")}  
💸 Biaya Admin   : Rp ${fee.toLocaleString("id-ID")}  

━━━━━━━━━━━━━━━━━━
⚠️ *Alasan Gagal:*  
- QR sudah tidak valid / kadaluarsa.  
- Nominal yang dibayarkan tidak sesuai.  
- Pembayaran dibatalkan oleh pengguna.  

━━━━━━━━━━━━━━━━━━
📌 Silakan ulangi deposit dengan perintah:  
.deposit <nominal>  

Jika masalah berlanjut, hubungi admin support.
━━━━━━━━━━━━━━━━━━
`.trim();

    const expiredText = `
━━━━━━━━━━━━━━━━━━
⌛ *INVOICE KADALUARSA*
━━━━━━━━━━━━━━━━━━

📌 *Detail Transaksi*  
🆔 ID Transaksi  : ${d.id}  
👤 Akun Pengguna : @${sender.split("@")[0]}  
📅 Tanggal       : ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}

💰 Nominal       : Rp ${nominalUser.toLocaleString("id-ID")}  
💸 Biaya Admin   : Rp ${fee.toLocaleString("id-ID")}  

━━━━━━━━━━━━━━━━━━
⚠️ Status: EXPIRED  
Invoice sudah melewati batas waktu (5 menit).  

📌 Tindakan Sistem:  
- Invoice otomatis dihapus.  
- Saldo tidak diproses.  

━━━━━━━━━━━━━━━━━━
👉 Silakan buat deposit baru dengan perintah:  
.deposit <nominal>
━━━━━━━━━━━━━━━━━━
`.trim();

    // --- Kirim Invoice ---
    const messageOptions = {
      caption: invoiceText,
      footer: "🔰 Sistem Deposit Otomatis",
      buttons: [
        {
          buttonId: `.cekstatus ${d.id}`,
          buttonText: { displayText: "🔄 Cek Status Manual" },
          type: 1,
        },
        {
          buttonId: `.canceldeposit ${d.id}`,
          buttonText: { displayText: "❌ Batalkan Manual" },
          type: 1,
        },
      ],
      headerType: 4,
    };

    if (d.qr_image_url) {
      messageOptions.image = { url: d.qr_image_url };
    } else {
      messageOptions.image = qrBuffer;
    }

    const sentInvoice = await bani.sendMessage(
      m.key.remoteJid,
      messageOptions,
      { quoted: m }
    );

    // Hapus pesan "mohon tunggu"
    await bani.sendMessage(m.key.remoteJid, { delete: initialReply.key });

    // --- Polling Status ---
    const checkInterval = 15000; // 15 detik
    const expiryTime = 5 * 60 * 1000; // 5 menit
    const startTime = Date.now();

    const checkStatusInterval = setInterval(async () => {
      if (Date.now() - startTime > expiryTime) {
        clearInterval(checkStatusInterval);

        const currentHistory = JSON.parse(fs.readFileSync(historyFilePath));
        if (currentHistory[d.id] && currentHistory[d.id].status === "pending") {
          await bani.sendMessage(m.key.remoteJid, { delete: sentInvoice.key });
          await m.reply(expiredText);
          currentHistory[d.id].status = "expired";
          fs.writeFileSync(
            historyFilePath,
            JSON.stringify(currentHistory, null, 2)
          );
        }
        return;
      }

      try {
        const statusResponse = await axios.post(
          statusUrl,
          { id: d.id, api_key: apiKey },
          { headers: { "Content-Type": "application/json" } }
        );
        const currentStatus = statusResponse.data?.data?.status;

        if (currentStatus === "success") {
          clearInterval(checkStatusInterval);

          const successAmount = statusResponse.data.data.get_balance;
          await m.reply(successText(successAmount));

          const currentHistory = JSON.parse(fs.readFileSync(historyFilePath));
          if (currentHistory[d.id]) {
            currentHistory[d.id].status = "success";
            fs.writeFileSync(
              historyFilePath,
              JSON.stringify(currentHistory, null, 2)
            );
          }

          await bani.sendMessage(m.key.remoteJid, { delete: sentInvoice.key });
        } else if (currentStatus === "failed") {
          clearInterval(checkStatusInterval);

          await m.reply(failedText);

          const currentHistory = JSON.parse(fs.readFileSync(historyFilePath));
          if (currentHistory[d.id]) {
            currentHistory[d.id].status = "failed";
            fs.writeFileSync(
              historyFilePath,
              JSON.stringify(currentHistory, null, 2)
            );
          }

          await bani.sendMessage(m.key.remoteJid, { delete: sentInvoice.key });
        }
      } catch (pollError) {
        console.error("Error saat polling status:", pollError.message);
      }
    }, checkInterval);
  } catch (err) {
    console.error(
      "Error saat membuat deposit:",
      err.response ? err.response.data : err.message
    );
    m.reply("❌ Terjadi kesalahan saat menghubungi server pembayaran.");
  }
};

handler.command = ["deposit"];
handler.tags = ["payment"];
handler.help = ["deposit <nominal>"];

module.exports = handler;