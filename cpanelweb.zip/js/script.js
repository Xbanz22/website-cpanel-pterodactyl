// Cek di halaman mana kita berada
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('registerForm')) {
        handleRegister();
    }
    if (document.getElementById('loginForm')) {
        handleLogin();
    }
    if (document.getElementById('createPanelForm')) {
        handlePanelCreation();
    }
    if (document.getElementById('loading')) {
        simulateLoadingAndShowData();
    }
});

function handleRegister() {
    const form = document.getElementById('registerForm');
    const button = form.querySelector('button');

    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        button.disabled = true;
        button.textContent = 'Mendaftar...';

        const formData = {
            username: form.username.value,
            email: form.email.value,
            password: form.password.value,
        };

        try {
            const response = await fetch('/api/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData),
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message);
            }

            alert(result.message + ' Anda akan diarahkan ke halaman login.');
            window.location.href = 'login.html';

        } catch (error) {
            alert('Error: ' + error.message);
        } finally {
            button.disabled = false;
            button.textContent = 'Daftar';
        }
    });
}

function handleLogin() {
    const form = document.getElementById('loginForm');
    const button = form.querySelector('button');

    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        button.disabled = true;
        button.textContent = 'Logging In...';

        const formData = {
            username: form.username.value,
            password: form.password.value,
        };

        try {
            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData),
            });
            
            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.message);
            }

            alert(result.message + ' Anda akan diarahkan ke halaman pembuatan panel.');
            sessionStorage.setItem('loggedInUser', formData.username);
            window.location.href = 'create-panel.html';

        } catch (error) {
            alert('Error: ' + error.message);
        } finally {
            button.disabled = false;
            button.textContent = 'Login';
        }
    });
}

// Fungsi handlePanelCreation, simulateLoadingAndShowData, dan generateRandomPassword
// tetap sama seperti sebelumnya karena tidak berinteraksi langsung dengan database.

function handlePanelCreation() {
    const form = document.getElementById('createPanelForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();

        const panelUsername = form.panelUsername.value;
        const server = form.server.options[form.server.selectedIndex].text;

        const panelDetails = {
            username: panelUsername,
            server: server,
            password: generateRandomPassword(12),
            loginLink: `https://${server.split(' ')[1].toLowerCase()}.domain.com/${panelUsername}`
        };

        sessionStorage.setItem('panelDetails', JSON.stringify(panelDetails));
        window.location.href = 'panel-data.html';
    });
}

function simulateLoadingAndShowData() {
    const loadingDiv = document.getElementById('loading');
    const panelDataDiv = document.getElementById('panelData');
    const panelDetails = JSON.parse(sessionStorage.getItem('panelDetails'));

    if (!panelDetails) {
        loadingDiv.innerHTML = "<p>Data panel tidak ditemukan. Silakan buat panel terlebih dahulu.</p>";
        return;
    }

    setTimeout(() => {
        loadingDiv.style.display = 'none';
        document.getElementById('dataUsername').textContent = panelDetails.username;
        document.getElementById('dataPassword').textContent = panelDetails.password;
        document.getElementById('dataServer').textContent = panelDetails.server;
        const linkElement = document.getElementById('dataLink');
        linkElement.href = '#';
        linkElement.textContent = panelDetails.loginLink;
        panelDataDiv.style.display = 'block';
    }, 3000);
}

function generateRandomPassword(length) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
    let password = '';
    for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return password;
}